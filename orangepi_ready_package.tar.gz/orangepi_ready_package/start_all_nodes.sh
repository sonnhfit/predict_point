#!/bin/bash

# Startup script for all ROS2 nodes on Orange Pi Zero 2W

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"

echo "🚀 Starting ROS2 nodes on Orange Pi Zero 2W..."

# Check if ROS2 is available
if [ -f "/opt/ros/kilted/setup.bash" ]; then
    source /opt/ros/kilted/setup.bash
    echo "✅ Sourced ROS2 kilted environment"
else
    echo "❌ Error: ROS2 kilted environment not found"
    echo "Please install ROS2 kilted on Orange Pi Zero 2W"
    exit 1
fi

# Find all node binaries
NODE_BINARIES=$(find $BIN_DIR -name "*_node" -type f)
NODE_COUNT=$(echo "$NODE_BINARIES" | wc -l | tr -d ' ')

if [ $NODE_COUNT -eq 0 ]; then
    echo "❌ Error: No node binaries found in $BIN_DIR"
    exit 1
fi

# Make all binaries executable
for node in $NODE_BINARIES; do
    chmod +x $node
done

echo "✅ $NODE_COUNT node(s) are executable"

# Function to handle cleanup
cleanup() {
    echo ""
    echo "🛑 Stopping all nodes..."
    for pid in "${NODE_PIDS[@]}"; do
        kill $pid 2>/dev/null
    done
    echo "✅ All nodes stopped"
    exit 0
}

# Set trap for cleanup
trap cleanup SIGINT

# Start nodes in background
echo ""
NODE_PIDS=()
for node in $NODE_BINARIES; do
    node_name=$(basename $node)
    echo "🚀 Starting $node_name..."
    $node &
    PID=$!
    NODE_PIDS+=($PID)
    echo "   PID: $PID"
done

echo ""
echo "✅ All $NODE_COUNT node(s) are running!"
echo ""
echo "📡 Available ROS2 topics:"
ros2 topic list
echo ""
echo "🎯 To listen to messages, run:"
echo "   ros2 topic echo /<topic_name>"
echo ""
echo "⏹️  Press Ctrl+C to stop all nodes"

# Wait for all background processes
wait
