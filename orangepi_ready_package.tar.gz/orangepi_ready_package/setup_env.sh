#!/bin/bash
export LD_LIBRARY_PATH=$(dirname "$0")/lib:$LD_LIBRARY_PATH
export ROS_DOMAIN_ID=42
