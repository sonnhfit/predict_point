from launch import LaunchDescription
from launch.actions import ExecuteProcess
import os

def generate_launch_description():
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    bin_dir = os.path.join(current_dir, '..', 'bin')
    
    # Find all node binaries
    node_binaries = []
    if os.path.exists(bin_dir):
        for filename in os.listdir(bin_dir):
            if filename.endswith('_node'):
                node_binaries.append(filename)
    
    # Create launch description with all nodes
    processes = []
    for node_binary in node_binaries:
        processes.append(
            ExecuteProcess(
                cmd=[os.path.join(bin_dir, node_binary)],
                name=node_binary,
                output='screen'
            )
        )
    
    return LaunchDescription(processes)
