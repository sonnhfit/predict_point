from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_ros2',
            executable='hello_world_node',
            name='hello_world_node',
            output='screen'
        ),
        Node(
            package='demo_ros2',
            executable='publisher_node',
            name='publisher_node',
            output='screen'
        ),
        Node(
            package='demo_ros2',
            executable='slam_nav_map_node',
            name='slam_nav_map_node',
            output='screen'
        ),
    ])
