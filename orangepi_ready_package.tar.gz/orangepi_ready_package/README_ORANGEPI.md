# ROS2 Application for Orange Pi Zero 2W

Ready-to-run package with all available nodes.

## 📋 What's Included
- All available ROS2 nodes (automatically detected)
- Multi-node launch file
- Easy startup scripts
- Dynamic node management

## 🚀 Quick Start

1. **Extract and setup:**
   ```bash
   tar -xzf orangepi_ready_package.tar.gz
   cd orangepi_ready_package
   ./setup_on_orangepi.sh
   ```

2. **Run all nodes:**
   ```bash
   ./start_all_nodes.sh
   ```

3. **Or use launch file:**
   ```bash
   ./run_with_launch.sh
   ```

## 📡 Check if it's working
Open another terminal and run:
```bash
source /opt/ros/kilted/setup.bash
ros2 topic list
ros2 topic echo /<topic_name>
```

## 🔧 Requirements
- Orange Pi Zero 2W with Ubuntu 22.04
- ROS2 kilted installed
- ARM64 architecture

## 🎯 Features
- ✅ All nodes pre-compiled for ARM64
- ✅ Dynamic node detection
- ✅ Easy startup scripts
- ✅ Multi-node coordination
- ✅ Source code protected

## 🔄 Adding New Nodes
The package automatically detects all available nodes. To add new nodes:
1. Build your new node using the build system
2. Run the build_and_package.sh script again
3. The new node will be automatically included in the package
