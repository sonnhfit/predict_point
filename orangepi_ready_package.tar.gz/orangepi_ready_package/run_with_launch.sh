#!/bin/bash

# Run using ROS2 launch file

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="$SCRIPT_DIR/lib"

echo "🚀 Running all nodes using ROS2 launch file..."

# Set up library path for bundled libraries
if [ -d "$LIB_DIR" ]; then
    export LD_LIBRARY_PATH="$LIB_DIR:$LD_LIBRARY_PATH"
    echo "✅ Added bundled libraries to LD_LIBRARY_PATH"
fi

# Check if ROS2 is available
if [ -f "/opt/ros/kilted/setup.bash" ]; then
    source /opt/ros/kilted/setup.bash
    echo "✅ Sourced ROS2 kilted environment"
else
    echo "❌ Error: ROS2 kilted environment not found"
    exit 1
fi

# Make binaries executable
chmod +x $SCRIPT_DIR/bin/*

# Run using launch file (use orangepi_launch.py for Orange Pi)
ros2 launch $SCRIPT_DIR/launch/orangepi_launch.py
