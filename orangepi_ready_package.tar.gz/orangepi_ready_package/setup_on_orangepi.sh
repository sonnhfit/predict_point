#!/bin/bash

# Quick setup script for Orange Pi Zero 2W

set -e

echo "🔧 Setting up ROS2 application on Orange Pi Zero 2W..."

# Check architecture
ARCH=$(uname -m)
if [ "$ARCH" != "aarch64" ]; then
    echo "⚠️  Warning: This script is intended for Orange Pi Zero 2W (ARM64)"
    echo "   Current architecture: $ARCH"
    echo "   Continuing anyway..."
fi

# Check ROS2
if [ ! -f "/opt/ros/kilted/setup.bash" ]; then
    echo "❌ Error: ROS2 kilted not found"
    echo "Please install ROS2 kilted first"
    exit 1
fi

# Count available nodes (exclude macOS resource fork files starting with ._)
NODE_COUNT=$(find bin -name "*_node" -type f ! -name "._*" | wc -l | tr -d ' ')

# Make all scripts executable
chmod +x start_all_nodes.sh
chmod +x run_with_launch.sh
chmod +x bin/*

echo ""
echo "✅ Setup completed!"
echo "📊 Found $NODE_COUNT node(s) available"
echo ""
echo "🎯 To run all nodes:"
echo "   ./start_all_nodes.sh"
echo ""
echo "🎯 To run with launch file:"
echo "   ./run_with_launch.sh"
echo ""
echo "📡 Check topics:"
echo "   source /opt/ros/kilted/setup.bash"
echo "   ros2 topic list"
